Eila G�mez Hidalgo.

Pr�ctica realizada en 3D Max 2017.